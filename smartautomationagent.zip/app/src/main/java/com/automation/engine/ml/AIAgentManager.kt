package com.automation.engine.ml

import android.content.Context
import android.util.Log
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object AIAgentManager {
    private const val TAG = "AIAgentManager"
    private const val MODEL_URL = "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/main/gemma-4-E2B-it.litertlm"
    private const val MODEL_FILE_NAME = "model.litertlm"

    fun getModelFile(context: Context): File {
        return File(context.filesDir, MODEL_FILE_NAME)
    }

    fun isModelDownloaded(context: Context): Boolean {
        return getModelFile(context).exists()
    }

    suspend fun downloadModel(context: Context, onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        val outputFile = getModelFile(context)
        if (outputFile.exists()) {
            outputFile.delete()
        }

        try {
            val url = URL(MODEL_URL)
            val connection = url.openConnection() as HttpURLConnection
            connection.connect()

            if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                Log.e(TAG, "Server returned HTTP " + connection.responseCode + " " + connection.responseMessage)
                return@withContext false
            }

            val fileLength = connection.contentLength
            val input = BufferedInputStream(url.openStream(), 8192)
            val output = FileOutputStream(outputFile)

            val data = ByteArray(1024)
            var total: Long = 0
            var count: Int
            var lastProgress = 0

            while (input.read(data).also { count = it } != -1) {
                total += count
                if (fileLength > 0) {
                    val progress = (total * 100 / fileLength).toInt()
                    if (progress != lastProgress) {
                        lastProgress = progress
                        withContext(Dispatchers.Main) {
                            onProgress(progress)
                        }
                    }
                }
                output.write(data, 0, count)
            }

            output.flush()
            output.close()
            input.close()
            connection.disconnect()
            Log.d(TAG, "Model downloaded successfully: " + outputFile.absolutePath)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error downloading model: " + e.message)
            if (outputFile.exists()) {
                outputFile.delete()
            }
            false
        }
    }

    // Fixed: Removed SmartAccessibilityService dependency to avoid KAPT crashes
    suspend fun initializeAIAgent(context: Context): Boolean {
        val modelFile = getModelFile(context)
        if (!modelFile.exists()) {
            Log.e(TAG, "Cannot initialize agent. Model file missing.")
            return false
        }
        return LocalLlmBrain.getInstance(context).initializeModel(modelFile.absolutePath)
    }
}
