package com.automation.engine.ml

import android.content.Context
import android.util.Log
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LocalLlmBrain private constructor(private val context: Context) {

    private val TAG = "LocalLlmBrain"
    private var engine: Engine? = null
    private var conversation: Conversation? = null
    var isModelLoaded = false
        private set

    companion object {
        @Volatile
        private var INSTANCE: LocalLlmBrain? = null

        fun getInstance(context: Context): LocalLlmBrain {
            return INSTANCE ?: synchronized(this) {
                val instance = LocalLlmBrain(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }

    suspend fun initializeModel(modelPath: String): Boolean = withContext(Dispatchers.IO) {
        if (isModelLoaded) return@withContext true
        val modelFile = File(modelPath)
        if (!modelFile.exists()) {
            Log.e(TAG, "Model missing at: $modelPath")
            return@withContext false
        }

        return@withContext try {
            val config = EngineConfig(
                modelPath = modelPath,
                backend = Backend.CPU(), // Safe CPU processing
                cacheDir = context.cacheDir.absolutePath
            )
            val newEngine = Engine(config)
            newEngine.initialize()
            engine = newEngine

            // Safe conversational config without complex tools for now
            val conversationConfig = ConversationConfig(
                systemInstruction = Contents.of(
                    "You are Raj Bhai's Personal AI Agent. You must answer clearly and concisely."
                )
            )

            conversation = newEngine.createConversation(conversationConfig)
            isModelLoaded = true
            Log.d(TAG, "LiteRT-LM Brain fully initialized!")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Initialization failed: ${e.message}")
            false
        }
    }

    suspend fun think(prompt: String): String = withContext(Dispatchers.Default) {
        if (!isModelLoaded || conversation == null) {
            return@withContext "Error: Local LLM is offline. Load the model first."
        }
        return@withContext try {
            val response = conversation?.sendMessage(prompt) ?: "No response from AI."
            response
        } catch (e: Exception) {
            Log.e(TAG, "Inference error: ${e.message}")
            "Error: ${e.message}"
        }
    }

    fun unloadModel() {
        try {
            conversation?.close()
            engine?.close()
            conversation = null
            engine = null
            isModelLoaded = false
            System.gc()
            Runtime.getRuntime().gc()
            Log.d(TAG, "Local brain successfully unloaded from RAM.")
        } catch (e: Exception) {
            Log.e(TAG, "Error unloading model: ${e.message}")
        }
    }
}
