// File: YoloVisionEngine.kt
package com.automation.engine.ml

import android.content.Context
import android.graphics.Bitmap
import android.graphics.RectF
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.ops.NormalizeOp
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.ResizeOp
import java.io.FileInputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import kotlin.math.max
import kotlin.math.min

data class DetectionResult(
    val boundingBox: RectF,
    val confidence: Float,
    val classIndex: Int
)

class YoloVisionEngine(private val context: Context) {

    private var interpreter: Interpreter? = null
    private val inputSize = 640 
    private val numBoundingBoxes = 8400 
    private val numClasses = 80 

    private fun loadModelFile(): MappedByteBuffer {
        val fileDescriptor = context.assets.openFd("yolov8n_quantized.tflite")
        val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
        val fileChannel = inputStream.channel
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, fileDescriptor.startOffset, fileDescriptor.declaredLength)
    }

    fun initialize() {
        val options = Interpreter.Options().apply { setNumThreads(2) }
        interpreter = Interpreter(loadModelFile(), options)
    }

    fun scanImage(bitmap: Bitmap): DetectionResult? {
        if (interpreter == null) initialize()

        val imageProcessor = ImageProcessor.Builder()
           .add(ResizeOp(inputSize, inputSize, ResizeOp.ResizeMethod.BILINEAR))
           .add(NormalizeOp(0f, 255f))
           .build()

        var tensorImage = TensorImage(org.tensorflow.lite.DataType.FLOAT32)
        tensorImage.load(bitmap)
        tensorImage = imageProcessor.process(tensorImage)

        val outputArray = Array(1) { Array(84) { FloatArray(8400) } }
        
        interpreter?.run(tensorImage.buffer, outputArray)

        val detections = mutableListOf<DetectionResult>()
        val confidenceThreshold = 0.5f

        for (i in 0 until numBoundingBoxes) {
            var maxClassConf = 0f
            var classIndex = -1

            for (c in 0 until numClasses) {
                val conf = outputArray[0][4 + c][i]
                if (conf > maxClassConf) {
                    maxClassConf = conf
                    classIndex = c
                }
            }

            if (maxClassConf >= confidenceThreshold) {
                val cx = outputArray[0][0][i]
                val cy = outputArray[0][1][i]
                val w = outputArray[0][2][i]
                val h = outputArray[0][3][i]

                val scaleX = bitmap.width.toFloat() / inputSize
                val scaleY = bitmap.height.toFloat() / inputSize
                
                val x1 = max(0f, cx - w / 2f) * scaleX
                val y1 = max(0f, cy - h / 2f) * scaleY
                val x2 = min(bitmap.width.toFloat() - 1f, cx + w / 2f) * scaleX
                val y2 = min(bitmap.height.toFloat() - 1f, cy + h / 2f) * scaleY

                detections.add(DetectionResult(RectF(x1, y1, x2, y2), maxClassConf, classIndex))
            }
        }

        val finalDetections = applyNMS(detections, 0.45f)
        
        interpreter?.close()
        interpreter = null
        
        return finalDetections.maxByOrNull { it.confidence }
    }

    private fun applyNMS(detections: List<DetectionResult>, iouThreshold: Float): List<DetectionResult> {
        val sorted = detections.sortedByDescending { it.confidence }
        val selected = mutableListOf<DetectionResult>()

        for (detection in sorted) {
            var shouldSelect = true
            for (existing in selected) {
                if (calculateIoU(detection.boundingBox, existing.boundingBox) > iouThreshold) {
                    shouldSelect = false
                    break
                }
            }
            if (shouldSelect) selected.add(detection)
        }
        return selected
    }

    private fun calculateIoU(box1: RectF, box2: RectF): Float {
        val interX1 = max(box1.left, box2.left)
        val interY1 = max(box1.top, box2.top)
        val interX2 = min(box1.right, box2.right)
        val interY2 = min(box1.bottom, box2.bottom)

        val interArea = max(0f, interX2 - interX1) * max(0f, interY2 - interY1)
        val box1Area = (box1.right - box1.left) * (box1.bottom - box1.top)
        val box2Area = (box2.right - box2.left) * (box2.bottom - box2.top)

        return interArea / (box1Area + box2Area - interArea)
    }
}
