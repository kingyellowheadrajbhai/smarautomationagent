package com.automation.engine

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.lifecycleScope
import com.automation.engine.db.AppDatabase
import com.automation.engine.db.ChatMessageEntity
import com.automation.engine.db.ChatSessionEntity
import com.automation.engine.db.SceneEntity
import com.automation.engine.ml.AIAgentManager
import com.automation.engine.ml.LocalLlmBrain
import java.util.ArrayList
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private val TAG = "MainActivity"
    
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var layoutChatMessages: LinearLayout
    private lateinit var scrollChat: ScrollView
    private lateinit var editChatInput: EditText
    private lateinit var layoutSettingsOverlay: FrameLayout
    private lateinit var layoutSessionList: LinearLayout
    private lateinit var tvServiceStatus: TextView
    private lateinit var btnToggleService: Button
    private lateinit var etConfidence: EditText
    private lateinit var etDelay: EditText
    private lateinit var editLlmPath: EditText
    private lateinit var txtRamTelemetry: TextView
    private lateinit var txtConsoleLogs: TextView
    private lateinit var txtQueueTelemetry: TextView
    private lateinit var editScriptPaste: EditText
    private lateinit var editTargetClass: EditText
    private lateinit var switchAiOptimization: SwitchCompat
    private lateinit var seekConf: SeekBar
    private lateinit var seekHoldDelay: SeekBar
    private lateinit var txtConfValue: TextView
    private lateinit var txtHoldDelayValue: TextView

    private lateinit var sharedPrefs: SharedPreferences
    private var currentSessionId: Int = -1
    private val mainScope = CoroutineScope(Dispatchers.Main)
    private val telemetryHandler = Handler(Looper.getMainLooper())

    private val consoleReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent != null) {
                if (intent.action == "com.automation.engine.ACTION_LOG_EVENT") {
                    val log = intent.getStringExtra("log_data") ?: ""
                    appendConsoleLog(log)
                } else if (intent.action == "com.automation.engine.ACTION_REFRESH_DB") {
                    refreshQueueTelemetry()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sharedPrefs = getSharedPreferences("SmartAutomationPrefs", Context.MODE_PRIVATE)

        drawerLayout = findViewById(R.id.drawer_layout)
        layoutChatMessages = findViewById(R.id.layout_chat_messages)
        scrollChat = findViewById(R.id.scroll_chat)
        editChatInput = findViewById(R.id.edit_chat_input)
        layoutSettingsOverlay = findViewById(R.id.layout_settings_overlay)
        layoutSessionList = findViewById(R.id.layout_session_list)
        tvServiceStatus = findViewById(R.id.tv_service_status)
        btnToggleService = findViewById(R.id.btn_toggle_service)
        etConfidence = findViewById(R.id.et_confidence)
        etDelay = findViewById(R.id.et_delay)
        editLlmPath = findViewById(R.id.edit_llm_path)
        txtRamTelemetry = findViewById(R.id.txt_ram_telemetry)
        txtConsoleLogs = findViewById(R.id.txt_console_logs)
        txtQueueTelemetry = findViewById(R.id.txt_queue_telemetry)
        editScriptPaste = findViewById(R.id.edit_script_paste)
        editTargetClass = findViewById(R.id.edit_target_class)
        switchAiOptimization = findViewById(R.id.switch_ai_optimization)
        seekConf = findViewById(R.id.seek_conf)
        seekHoldDelay = findViewById(R.id.seek_hold_delay)
        txtConfValue = findViewById(R.id.txt_conf_value)
        txtHoldDelayValue = findViewById(R.id.txt_hold_delay_value)

        val btnMenu = findViewById<ImageButton>(R.id.btn_menu)
        val btnSettings = findViewById<ImageButton>(R.id.btn_settings)
        val btnSendMessage = findViewById<ImageButton>(R.id.btn_send_message)
        val btnCloseSettings = findViewById<Button>(R.id.btn_close_settings)
        val btnNewChat = findViewById<Button>(R.id.btn_new_chat)
        val btnWipeHistory = findViewById<Button>(R.id.btn_wipe_history)
        val btnSaveSettings = findViewById<Button>(R.id.btn_save_settings)
        val btnTriggerZoom = findViewById<Button>(R.id.btn_trigger_zoom)
        val btnTriggerScroll = findViewById<Button>(R.id.btn_trigger_scroll)
        val btnLoadLlm = findViewById<Button>(R.id.btn_load_llm)
        val btnUnloadLlm = findViewById<Button>(R.id.btn_unload_llm)
        val btnParseScript = findViewById<Button>(R.id.btn_parse_script)
        val btnClearQueue = findViewById<Button>(R.id.btn_clear_queue)
        val btnStartQueue = findViewById<Button>(R.id.btn_start_queue)

        loadSavedSettings()
        startRamTelemetryLoop()
        refreshQueueTelemetry()

        btnMenu.setOnClickListener { drawerLayout.openDrawer(GravityCompat.START) }
        btnNewChat.setOnClickListener { startNewChatSession(); drawerLayout.closeDrawer(GravityCompat.START) }
        btnWipeHistory.setOnClickListener { wipeChatHistory() }
        btnSettings.setOnClickListener { layoutSettingsOverlay.visibility = View.VISIBLE }
        btnCloseSettings.setOnClickListener { layoutSettingsOverlay.visibility = View.GONE }
        btnToggleService.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btnSaveSettings.setOnClickListener { saveConfig() }

        seekConf.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                txtConfValue.text = "YOLOv8 Scan Threshold: ${progress / 100f}"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        seekHoldDelay.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                txtHoldDelayValue.text = "Long-Press Zoom Delay: $progress ms"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        btnTriggerZoom.setOnClickListener {
            if (isAccessibilityServiceEnabled()) {
                sendBroadcast(Intent("com.automation.engine.TRIGGER_ZOOM"))
                Toast.makeText(this, "Zoom Signal Sent", Toast.LENGTH_SHORT).show()
            }
        }

        btnTriggerScroll.setOnClickListener {
            if (isAccessibilityServiceEnabled()) {
                sendBroadcast(Intent("com.automation.engine.TRIGGER_SCROLL"))
                Toast.makeText(this, "Scroll Signal Sent", Toast.LENGTH_SHORT).show()
            }
        }

        btnSendMessage.setOnClickListener {
            val userText = editChatInput.text.toString().trim()
            if (userText.isNotEmpty()) sendMessage(userText)
        }

        btnLoadLlm.setOnClickListener {
            val path = editLlmPath.text.toString().trim()
            if (path.isNotEmpty()) {
                appendConsoleLog("[AI Brain] Initializing model...")
                mainScope.launch {
                    val success = withContext(Dispatchers.IO) {
                        LocalLlmBrain.getInstance(applicationContext).initializeModel(path)
                    }
                    if (success) {
                        appendConsoleLog("[AI Brain Success] Local LLM ONLINE!")
                    } else {
                        appendConsoleLog("[AI Brain Error] Failed to load model.")
                    }
                }
            }
        }

        btnUnloadLlm.setOnClickListener {
            LocalLlmBrain.getInstance(applicationContext).unloadModel()
            appendConsoleLog("[AI Brain] Unloaded model. RAM freed!")
        }

        btnParseScript.setOnClickListener {
            val rawScript = editScriptPaste.text.toString().trim()
            if (rawScript.isNotEmpty()) {
                appendConsoleLog("[Parser] Parsing script...")
                mainScope.launch {
                    withContext(Dispatchers.IO) {
                        val sceneList = ArrayList<SceneEntity>()
                        val blocks = rawScript.split("---")
                        for (block in blocks) {
                            val trimmedBlock = block.trim()
                            if (trimmedBlock.isNotEmpty()) {
                                sceneList.add(SceneEntity(sceneCode = "C-Scene", sceneTitle = "Parsed", rawContent = trimmedBlock, status = "PENDING"))
                            }
                        }
                        val db = AppDatabase.getDatabase(applicationContext)
                        db.sceneDao().clearAllScenes()
                        db.sceneDao().insertScenes(sceneList)
                    }
                    appendConsoleLog("[Parser Success] Scripts loaded!")
                    refreshQueueTelemetry()
                }
            }
        }

        btnClearQueue.setOnClickListener {
            mainScope.launch {
                withContext(Dispatchers.IO) {
                    AppDatabase.getDatabase(applicationContext).sceneDao().clearAllScenes()
                }
                appendConsoleLog("[Queue] Cleared.")
                refreshQueueTelemetry()
            }
        }

        btnStartQueue.setOnClickListener {
            if (isAccessibilityServiceEnabled()) {
                sendBroadcast(Intent("com.automation.engine.TRIGGER_QUEUE"))
                appendConsoleLog("[Queue Controller] Autopilot Triggered!")
            }
        }

        refreshSessionList()

        lifecycleScope.launch {
            if (!AIAgentManager.isModelDownloaded(this@MainActivity)) {
                Toast.makeText(this@MainActivity, "Downloading 0.5B AI Brain...", Toast.LENGTH_LONG).show()
                val success = withContext(Dispatchers.IO) {
                    AIAgentManager.downloadModel(this@MainActivity) { progress ->
                        Log.d(TAG, "Download Progress: $progress%")
                    }
                }
                if (success) initializeBrain()
            } else {
                initializeBrain()
            }
        }
    }

    private fun initializeBrain() {
        if (isAccessibilityServiceEnabled()) {
            lifecycleScope.launch {
                Log.d(TAG, "Accessibility active. Brain initializing...")
                withContext(Dispatchers.IO) {
                    AIAgentManager.initializeAIAgent(this@MainActivity)
                }
                appendConsoleLog("[System] LLM Armed!")
            }
        }
    }

    private fun startNewChatSession() {
        lifecycleScope.launch {
            val sessionId = withContext(Dispatchers.IO) {
                val db = AppDatabase.getDatabase(applicationContext)
                db.chatDao().insertSession(ChatSessionEntity(title = "New Conversation")).toInt()
            }
            currentSessionId = sessionId
            layoutChatMessages.removeAllViews()
            refreshSessionList()
            addMessageToLayout("ai", "Hello Raj Bhai! I am your local AI agent.")
        }
    }

    private fun sendMessage(messageText: String) {
        if (currentSessionId == -1) {
            lifecycleScope.launch {
                val sessionId = withContext(Dispatchers.IO) {
                    AppDatabase.getDatabase(applicationContext).chatDao().insertSession(ChatSessionEntity(title = "Chat")).toInt()
                }
                currentSessionId = sessionId
                executeSendMessageSequence(messageText)
            }
        } else {
            executeSendMessageSequence(messageText)
        }
    }

    private fun executeSendMessageSequence(messageText: String) {
        editChatInput.setText("")
        addMessageToLayout("user", messageText)

        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                AppDatabase.getDatabase(applicationContext).chatDao().insertMessage(ChatMessageEntity(sessionId = currentSessionId, sender = "user", message = messageText))
            }
            val brain = LocalLlmBrain.getInstance(applicationContext)
            val aiResponse = if (brain.isModelLoaded) {
                appendConsoleLog("Thinking...")
                brain.think(messageText)
            } else {
                "AI is offline."
            }
            addMessageToLayout("ai", aiResponse)
            withContext(Dispatchers.IO) {
                AppDatabase.getDatabase(applicationContext).chatDao().insertMessage(ChatMessageEntity(sessionId = currentSessionId, sender = "ai", message = aiResponse))
            }
        }
    }

    private fun refreshSessionList() {
        lifecycleScope.launch {
            val sessions = withContext(Dispatchers.IO) {
                AppDatabase.getDatabase(applicationContext).chatDao().getAllSessions()
            }
            layoutSessionList.removeAllViews()
            for (session in sessions) {
                addSessionToDrawer(session)
            }
            if (sessions.isNotEmpty() && currentSessionId == -1) {
                loadSessionHistory(sessions[0].id)
            }
        }
    }

    private fun loadSessionHistory(sessionId: Int) {
        currentSessionId = sessionId
        lifecycleScope.launch {
            val messages = withContext(Dispatchers.IO) {
                AppDatabase.getDatabase(applicationContext).chatDao().getMessagesForSession(sessionId)
            }
            layoutChatMessages.removeAllViews()
            for (msg in messages) addMessageToLayout(msg.sender, msg.message)
        }
    }

    private fun wipeChatHistory() {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) { AppDatabase.getDatabase(applicationContext).chatDao().deleteAllSessions() }
            currentSessionId = -1
            layoutChatMessages.removeAllViews()
            layoutSessionList.removeAllViews()
            addMessageToLayout("ai", "History wiped.")
        }
    }

    private fun addMessageToLayout(sender: String, message: String) {
        val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = 8; bottomMargin = 8 }
        val textView = TextView(this).apply {
            text = message
            textSize = 14f
            setPadding(16, 12, 16, 12)
            setTextColor(android.graphics.Color.WHITE)
            maxWidth = (resources.displayMetrics.widthPixels * 0.75).toInt()
        }
        if (sender == "user") {
            params.gravity = Gravity.END
            textView.background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = 24f; setColor(android.graphics.Color.parseColor("#1E293B")) }
        } else {
            params.gravity = Gravity.START
            textView.background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = 24f; setColor(android.graphics.Color.parseColor("#121824")); setStroke(2, android.graphics.Color.parseColor("#00FF66")) }
            textView.setTextColor(android.graphics.Color.parseColor("#00FF66"))
        }
        textView.layoutParams = params
        layoutChatMessages.addView(textView)
        scrollChat.post { scrollChat.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun addSessionToDrawer(session: ChatSessionEntity) {
        val button = Button(this).apply {
            text = session.title
            setTextColor(android.graphics.Color.WHITE)
            background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = 12f; setColor(android.graphics.Color.parseColor("#1E293B")) }
            setOnClickListener { loadSessionHistory(session.id); drawerLayout.closeDrawer(GravityCompat.START) }
        }
        layoutSessionList.addView(button, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = 6; bottomMargin = 6 })
    }

    override fun onResume() {
        super.onResume()
        if (isAccessibilityServiceEnabled()) {
            tvServiceStatus.text = "ACTIVE 🟢"; tvServiceStatus.setTextColor(android.graphics.Color.GREEN); btnToggleService.text = "SETTINGS"
            initializeBrain()
        } else {
            tvServiceStatus.text = "DISABLED 🔴"; tvServiceStatus.setTextColor(android.graphics.Color.RED); btnToggleService.text = "ENABLE"
        }
    }

    private fun loadSavedSettings() {
        etConfidence.setText(sharedPreferences.getFloat("confidence", 0.65f).toString())
        etDelay.setText(sharedPreferences.getInt("delay", 400).toString())
        editTargetClass.setText(sharedPreferences.getInt("target_class", 0).toString())
        editLlmPath.setText(sharedPreferences.getString("llm_path", "/sdcard/Download/model.bin"))
    }

    private fun saveConfig() {
        sharedPreferences.edit().apply {
            putFloat("confidence", etConfidence.text.toString().toFloatOrNull() ?: 0.65f)
            putInt("delay", etDelay.text.toString().toIntOrNull() ?: 400)
            putInt("target_class", editTargetClass.text.toString().toIntOrNull() ?: 0)
            putString("llm_path", editLlmPath.text.toString().trim())
            apply()
        }
    }

    private fun appendConsoleLog(msg: String) { addMessageToLayout("ai", "[Logger] $msg") }

    private fun startRamTelemetryLoop() {
        val runnable = object : Runnable {
            override fun run() {
                val actManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val memInfo = ActivityManager.MemoryInfo()
                actManager.getMemoryInfo(memInfo)
                val availMem = memInfo.availMem / (1024 * 1024)
                txtRamTelemetry.text = "Free RAM: ${availMem}MB"
                txtRamTelemetry.setTextColor(if (availMem < 400) android.graphics.Color.RED else android.graphics.Color.parseColor("#00FF66"))
                telemetryHandler.postDelayed(this, 1500)
            }
        }
        telemetryHandler.post(runnable)
    }

    private fun refreshQueueTelemetry() {
        mainScope.launch {
            val count = withContext(Dispatchers.IO) { AppDatabase.getDatabase(applicationContext).sceneDao().getSceneCount() }
            txtQueueTelemetry.text = "Queue: $count Scenes Loaded"
        }
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val setting = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(setting)
        while (splitter.hasNext()) {
            if (splitter.next().equals("$packageName/${SmartAccessibilityService::class.java.name}", ignoreCase = true)) return true
        }
        return false
    }

    override fun onDestroy() {
        super.onDestroy()
        telemetryHandler.removeCallbacksAndMessages(null)
        try { unregisterReceiver(consoleReceiver) } catch (e: Exception) {}
    }
}