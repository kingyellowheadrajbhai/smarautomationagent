package com.automation.engine

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.FrameLayout
import androidx.annotation.RequiresApi
import com.automation.engine.db.AppDatabase
import com.automation.engine.db.SceneStatus
import com.automation.engine.ml.AIAgentManager
import com.automation.engine.ml.YoloVisionEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SmartAccessibilityService : AccessibilityService() {

    private val TAG = "SmartAutomationEngine"
    private val serviceScope = CoroutineScope(Dispatchers.IO)
    private lateinit var yoloVisionEngine: YoloVisionEngine
    private var overlayLayout: FrameLayout? = null

    private var confidenceThreshold = 0.65f
    private var scrollDuration = 400

    private val uiCommandReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                "com.automation.engine.TRIGGER_SCROLL" -> performScrollDown()
                "com.automation.engine.TRIGGER_ZOOM" -> performZoomHoldLogic(500f, 1000f)
                "com.automation.engine.TRIGGER_QUEUE" -> startSequentialSceneAutomation()
                "com.automation.engine.UPDATE_SETTINGS" -> {
                    confidenceThreshold = intent.getFloatExtra("confidence", 0.65f)
                    scrollDuration = intent.getIntExtra("delay", 400)
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "Service Connected. Initializing Vision Engine...")
        yoloVisionEngine = YoloVisionEngine(this)
        
        val filter = IntentFilter().apply {
            addAction("com.automation.engine.TRIGGER_SCROLL")
            addAction("com.automation.engine.TRIGGER_ZOOM")
            addAction("com.automation.engine.TRIGGER_QUEUE")
            addAction("com.automation.engine.UPDATE_SETTINGS")
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(uiCommandReceiver, filter, RECEIVER_EXPORTED)
        } else {
            registerReceiver(uiCommandReceiver, filter)
        }

        serviceScope.launch {
            if (AIAgentManager.isModelDownloaded(this@SmartAccessibilityService)) {
                AIAgentManager.initializeAIAgent(this@SmartAccessibilityService, this@SmartAccessibilityService)
            }
        }
    }

    fun startSequentialSceneAutomation() {
        serviceScope.launch {
            val db = AppDatabase.getDatabase(this@SmartAccessibilityService)
            val sceneDao = db.sceneDao()
            
            var activeScene = sceneDao.getNextPendingScene()
            
            if (activeScene == null) {
                Log.d(TAG, "क्यू में कोई PENDING सीन नहीं मिला!")
                return@launch
            }
            
            while (activeScene!= null) {
                Log.d(TAG, "प्रोसेसिंग सीन: ${activeScene.sceneCode}")
                
                activeScene.status = SceneStatus.PROCESSING
                sceneDao.updateScene(activeScene)
                
                val promptQuery = "इस कहानी के दृश्य के लिए एक बेहतरीन हॉलीवुड स्टाइल एआई वीडियो जनरेशन प्रॉम्प्ट लिखो। केवल प्रॉम्प्ट ही उत्तर में देना, कोई और बात मत लिखना:\n${activeScene.rawContent}"
                val smartPrompt = AIAgentManager.sendMessageToAI(promptQuery)
                
                activeScene.generatedPrompt = smartPrompt
                sceneDao.updateScene(activeScene)
                
                launchVideoGeneratorApp()
                delay(3000)
                
                pastePromptAndClickGenerate(smartPrompt)
                waitForGenerationToComplete()
                
                performYoloAssetSelection()
                delay(2000)
                
                exportVideoClip()
                delay(2000)
                
                activeScene.status = SceneStatus.COMPLETED
                sceneDao.updateScene(activeScene)
                
                Runtime.getRuntime().gc() 
                System.gc()
                delay(2000)
                
                activeScene = sceneDao.getNextPendingScene()
            }
        }
    }

    private fun launchVideoGeneratorApp() {
        val launchIntent = packageManager.getLaunchIntentForPackage("com.google.android.apps.youtube.producer")
        if (launchIntent!= null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(launchIntent)
        }
    }

    private fun pastePromptAndClickGenerate(prompt: String) {}
    private suspend fun waitForGenerationToComplete() { delay(15000) }
    private fun performYoloAssetSelection() { performZoomHoldLogic(500f, 1000f) }
    private fun exportVideoClip() {}

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(uiCommandReceiver)
        } catch (e: Exception) {
            Log.e(TAG, "onDestroy Error: ${e.message}")
        }
    }

    fun performZoomHoldLogic(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 1000)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    captureAndAnalyzeScreen()
                }
            }
        }, null)
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private fun captureAndAnalyzeScreen() {
        takeScreenshot(android.view.Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(screenshotResult: ScreenshotResult) {
                val hardwareBuffer = screenshotResult.hardwareBuffer
                val colorSpace = screenshotResult.colorSpace
                var bitmap = Bitmap.wrapHardwareBuffer(hardwareBuffer, colorSpace)
                
                if (bitmap!= null) {
                    bitmap = bitmap.copy(Bitmap.Config.ARGB_8888, false)
                    
                    serviceScope.launch {
                        val detection = yoloVisionEngine.scanImage(bitmap)
                        bitmap.recycle()
                        hardwareBuffer.close()
                        Runtime.getRuntime().gc() 

                        if (detection!= null && detection.confidence > confidenceThreshold) {
                            clickAtCoordinates(detection.boundingBox.centerX(), detection.boundingBox.centerY())
                        } else {
                            triggerSmartReminder()
                        }
                    }
                }
            }

            override fun onFailure(errorCode: Int) {
                Log.e(TAG, "स्क्रीनशॉट विफल: $errorCode")
            }
        })
    }

    private fun clickAtCoordinates(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 50)
        val click = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(click, null, null)
    }

    fun performScrollDown() {
        val displayMetrics = resources.displayMetrics
        val startX = displayMetrics.widthPixels / 2f
        val startY = displayMetrics.heightPixels * 0.8f
        val endY = displayMetrics.heightPixels * 0.2f

        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(startX, endY) 
        }

        val stroke = GestureDescription.StrokeDescription(path, 0, scrollDuration.toLong())
        val swipe = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(swipe, null, null)
    }

    private fun triggerSmartReminder() {
        Handler(Looper.getMainLooper()).post {
            val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                vibrator.vibrate(500)
            }

            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            overlayLayout = FrameLayout(this)
            
            val params = WindowManager.LayoutParams().apply {
                type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                format = PixelFormat.TRANSLUCENT
                flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                width = WindowManager.LayoutParams.WRAP_CONTENT
                height = WindowManager.LayoutParams.WRAP_CONTENT
                gravity = Gravity.CENTER
            }

            val inflater = LayoutInflater.from(this)
            val view = inflater.inflate(R.layout.overlay_reminder, overlayLayout)
            
            val btnContinue = view.findViewById<Button>(R.id.btn_continue)
            btnContinue.setOnClickListener {
                wm.removeView(overlayLayout)
                overlayLayout = null
            }

            wm.addView(overlayLayout, params)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
