// File: PromptDatabase.kt
package[span_18](start_span)[span_18](end_span)[span_20](start_span)[span_20](end_span) com.automation.engine.db

import android.content.Context
import androidx.room.*
import java.io.Serializable

// प्रॉम्प्ट टेबल की एंटिटी (Entity) [span_46](start_span)[span_46](end_span)
@Entity(tableName = "prompt_table")
data class PromptEntity(
    @PrimaryKey(autoGenerate = true) var id: Int = 0,
    val scriptName: String,
    val generatedPrompt: String,
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

// डेटा एक्सेस ऑब्जेक्ट (DAO) [span_47](start_span)[span_47](end_span)[span_48](start_span)[span_48](end_span)
@Dao
interface PromptDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrompt(prompt: PromptEntity)

    @Query("SELECT * FROM prompt_table ORDER BY id DESC LIMIT 1")
    suspend fun getLatestPrompt(): PromptEntity?
    
    @Query("DELETE FROM prompt_table")
    suspend fun clearAll()
}

// मुख्य डेटाबेस क्लास 
@Database(entities = [PromptEntity::class], version = 1, exportSchema = false)
abstract c[span_3](start_span)[span_3](end_span)lass AppDatabase : RoomDatabase() {
    abstract fun promptDao(): PromptDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "automation_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
