package com.automation.engine.db

import android.content.Context
import androidx.room.*
import java.io.Serializable

@Entity(tableName = "prompt_table")
data class PromptEntity(
    @PrimaryKey(autoGenerate = true) var id: Int = 0,
    val scriptName: String,
    val generatedPrompt: String,
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

@Dao
interface PromptDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrompt(prompt: PromptEntity)

    @Query("SELECT * FROM prompt_table ORDER BY id DESC LIMIT 1")
    suspend fun getLatestPrompt(): PromptEntity?
    
    @Query("DELETE FROM prompt_table")
    suspend fun clearAll()
}

@Entity(tableName = "scene_table")
data class SceneEntity(
    @PrimaryKey(autoGenerate = true) var id: Int = 0,
    val sceneCode: String,
    val sceneTitle: String,
    val rawContent: String,
    var generatedPrompt: String = "",
    var status: String = "PENDING"
) : Serializable

@Dao
interface SceneDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScenes(scenes: List<SceneEntity>)

    @Query("SELECT * FROM scenes_table WHERE status = 'PENDING' ORDER BY id ASC LIMIT 1")
    suspend fun getNextPendingScene(): SceneEntity?

    @Update
    suspend fun updateScene(scene: SceneEntity)

    @Query("SELECT COUNT(*) FROM scene_table")
    suspend fun getSceneCount(): Int

    @Query("SELECT COUNT(*) FROM scene_table WHERE status = 'COMPLETED'")
    suspend fun getCompletedCount(): Int

    @Query("SELECT * FROM scene_table ORDER BY id ASC")
    suspend fun getAllScenes(): List<SceneEntity>

    @Query("DELETE FROM scene_table")
    suspend fun clearAllScenes()
}

@Entity(tableName = "chat_session_table")
data class ChatSessionEntity(
    @PrimaryKey(autoGenerate = true) var id: Int = 0,
    val title: String,
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

@Entity(
    tableName = "chat_message_table",
    foreignKeys = arrayOf(
        ForeignKey(
            entity = ChatSessionEntity::class,
            parentColumns = arrayOf("id"),
            childColumns = arrayOf("sessionId"),
            onDelete = ForeignKey.CASCADE
        )
    ),
    indices = arrayOf(Index(value = arrayOf("sessionId")))
)
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) var id: Int = 0,
    val sessionId: Int,
    val sender: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

@Dao
interface ChatDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: ChatSessionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity)

    @Query("SELECT * FROM chat_session_table ORDER BY timestamp DESC")
    suspend fun getAllSessions(): List<ChatSessionEntity>

    @Query("SELECT * FROM chat_message_table WHERE sessionId = :sessionId ORDER BY timestamp ASC")
    suspend fun getMessagesForSession(sessionId: Int): List<ChatMessageEntity>

    @Query("DELETE FROM chat_session_table WHERE id = :sessionId")
    suspend fun deleteSession(sessionId: Int)

    @Query("DELETE FROM chat_session_table")
    suspend fun deleteAllSessions()
}

@Database(
    entities = arrayOf(PromptEntity::class, SceneEntity::class, ChatSessionEntity::class, ChatMessageEntity::class),
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun promptDao(): PromptDao
    abstract fun sceneDao(): SceneDao
    abstract fun chatDao(): ChatDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "automation_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
