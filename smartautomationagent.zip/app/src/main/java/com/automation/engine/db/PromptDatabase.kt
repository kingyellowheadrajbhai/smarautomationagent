package com.automation.engine.db

import android.content.Context
import androidx.room.*
import java.io.Serializable

// ==========================================
// 1. ENUM & TYPE CONVERTERS (KAPT FIX)
// ==========================================
enum class SceneStatus {
    PENDING,
    PROCESSING,
    COMPLETED,
    FAILED
}

class DatabaseConverters {
    @TypeConverter
    fun fromStatus(status: SceneStatus): String {
        return status.name
    }

    @TypeConverter
    fun toStatus(status: String): SceneStatus {
        return try {
            SceneStatus.valueOf(status)
        } catch (e: IllegalArgumentException) {
            SceneStatus.PENDING
        }
    }
}

// ==========================================
// 2. ENTITIES (TABLES)
// ==========================================
@Entity(tableName = "prompt_table")
data class PromptEntity(
    @PrimaryKey(autoGenerate = true) var id: Int = 0,
    val scriptName: String,
    val generatedPrompt: String,
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "scenes_table")
data class SceneEntity(
    @PrimaryKey(autoGenerate = true) var id: Int = 0,
    val sceneCode: String,
    val sceneTitle: String,
    val rawContent: String,
    var generatedPrompt: String = "",
    var status: SceneStatus = SceneStatus.PENDING
) : Serializable

@Entity(tableName = "chat_session_table")
data class ChatSessionEntity(
    @PrimaryKey(autoGenerate = true) var id: Int = 0,
    val title: String,
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

@Entity(
    tableName = "chat_message_table",
    foreignKeys = [
        ForeignKey(
            entity = ChatSessionEntity::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["sessionId"])
    ]
)
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) var id: Int = 0,
    val sessionId: Int,
    val sender: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

// ==========================================
// 3. DAOs (DATA ACCESS OBJECTS)
// ==========================================
@Dao
interface PromptDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrompt(prompt: PromptEntity)

    @Query("SELECT * FROM prompt_table ORDER BY id DESC LIMIT 1")
    suspend fun getLatestPrompt(): PromptEntity?
    
    @Query("DELETE FROM prompt_table")
    suspend fun clearAll()
}

@Dao
interface SceneDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScenes(scenes: List<SceneEntity>)

    @Query("SELECT * FROM scenes_table WHERE status = 'PENDING' ORDER BY id ASC LIMIT 1")
    suspend fun getNextPendingScene(): SceneEntity?

    @Update
    suspend fun updateScene(scene: SceneEntity)

    @Query("UPDATE scenes_table SET status = 'PENDING'")
    suspend fun resetQueue()

    @Query("DELETE FROM scenes_table")
    suspend fun clearQueue()

    @Query("SELECT COUNT(*) FROM scenes_table")
    suspend fun getSceneCount(): Int

    @Query("SELECT COUNT(*) FROM scenes_table WHERE status = 'COMPLETED'")
    suspend fun getCompletedCount(): Int

    @Query("SELECT * FROM scenes_table ORDER BY id ASC")
    suspend fun getAllScenes(): List<SceneEntity>
}

@Dao
interface ChatDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: ChatSessionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity)

    @Query("SELECT * FROM chat_session_table ORDER BY timestamp DESC")
    suspend fun getAllSessions(): List<ChatSessionEntity>

    @Query("SELECT * FROM chat_message_table WHERE sessionId = :sessionId ORDER BY timestamp ASC")
    suspend fun getMessagesForSession(sessionId: Int): List<ChatMessageEntity>

    @Query("DELETE FROM chat_session_table WHERE id = :sessionId")
    suspend fun deleteSession(sessionId: Int)

    @Query("DELETE FROM chat_session_table")
    suspend fun deleteAllSessions()
}

// ==========================================
// 4. MAIN DATABASE CLASS
// ==========================================
// 🚀 THE ULTIMATE KAPT FIX: Correct array syntax and TypeConverters added!
@Database(
    entities = [
        PromptEntity::class,
        SceneEntity::class,
        ChatSessionEntity::class,
        ChatMessageEntity::class
    ],
    version = 4,
    exportSchema = false
)
@TypeConverters(DatabaseConverters::class) // 🚨 KAPT WILL CRASH WITHOUT THIS!
abstract class AppDatabase : RoomDatabase() {
    abstract fun promptDao(): PromptDao
    abstract fun sceneDao(): SceneDao
    abstract fun chatDao(): ChatDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "automation_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
