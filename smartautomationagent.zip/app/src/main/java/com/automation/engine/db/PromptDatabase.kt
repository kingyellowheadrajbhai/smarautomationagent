package com.automation.engine.db

import android.content.Context
import androidx.room.*
import java.io.Serializable

// 1. प्रॉम्प्ट के लिए एंटिटी और DAO
@Entity(tableName = "prompt_table")
data class PromptEntity(
    @PrimaryKey(autoGenerate = true) var id: Int = 0,
    val scriptName: String,
    val generatedPrompt: String,
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

@Dao
interface PromptDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrompt(prompt: PromptEntity)

    @Query("SELECT * FROM prompt_table ORDER BY id DESC LIMIT 1")
    suspend fun getLatestPrompt(): PromptEntity?
    
    @Query("DELETE FROM prompt_table")
    suspend fun clearAll()
}

// 2. सीन-दर-सीन कतार (Queue) के लिए एंटिटी और DAO
@Entity(tableName = "scenes_table")
data class SceneEntity(
    @PrimaryKey(autoGenerate = true) var id: Int = 0,
    val sceneCode: String,
    val sceneTitle: String,
    val rawContent: String,
    var generatedPrompt: String = "",
    var status: String = "PENDING"
) : Serializable

@Dao
interface SceneDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScenes(scenes: List<SceneEntity>)

    @Query("SELECT * FROM scenes_table WHERE status = 'PENDING' ORDER BY id ASC LIMIT 1")
    suspend fun getNextPendingScene(): SceneEntity?

    @Update
    suspend fun updateScene(scene: SceneEntity)

    @Query("UPDATE scenes_table SET status = 'PENDING'")
    suspend fun resetQueue()

    @Query("DELETE FROM scenes_table")
    suspend fun clearQueue()
}

// 🚀 THE ULTIMATE FIX: यहाँ स्क्वायर ब्रैकेट्स [...] का उपयोग किया गया है
@Database(
    entities =, 
    version = 2, 
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun promptDao(): PromptDao
    abstract fun sceneDao(): SceneDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "automation_database"
                )
                // अगर डेटाबेस स्ट्रक्चर बदलता है तो यह बिना क्रैश किए उसे हैंडल करेगा
               .fallbackToDestructiveMigration()
               .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
